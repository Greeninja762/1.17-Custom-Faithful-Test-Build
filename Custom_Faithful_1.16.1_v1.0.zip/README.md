# 1.16.1-Custom-Faithful-Test-Build-
a repo for my resource pack(s)

i want to give credit to the guys that helped me make this:
faithfulteam: for the original pack that i made this out of.
seaofpixels: for some of the animated texture ideas that i had while looking at his amazing pack (seriously dude, nice fucking work)
My Brother: who made the color pallet that i used to make the diamond items much more blue instead of teal
